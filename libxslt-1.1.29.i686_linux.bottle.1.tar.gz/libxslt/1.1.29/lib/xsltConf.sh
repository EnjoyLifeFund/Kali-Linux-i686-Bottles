#
# Configuration file for using the xslt library
#
XSLT_LIBDIR="-L@@HOMEBREW_PREFIX@@/Cellar/libxslt/1.1.29/lib"
XSLT_LIBS="-lxslt  -L@@HOMEBREW_PREFIX@@/Cellar/libxml2/2.9.5/lib -lxml2 -L@@HOMEBREW_PREFIX@@/Cellar/zlib/1.2.11/lib -lz -lm -ldl -lm "
XSLT_INCLUDEDIR="-I@@HOMEBREW_PREFIX@@/Cellar/libxslt/1.1.29/include"
MODULE_VERSION="xslt-1.1.29"
