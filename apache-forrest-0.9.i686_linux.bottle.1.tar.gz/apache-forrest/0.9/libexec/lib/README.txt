See the accompanying licenses for each library
and the file ../NOTICE.txt

Naming convention for library filenames:
* Include the actual release number,
* If it is a pre-release then use their SVN revision number,
* Otherwise use the date.

The Apache Cocoon libraries are updated too often,
so please see our 'svn log' for the commit message
which will indicate the Cocoon revision number.
If you cannot use 'svn log' then see the online interface:
http://svn.apache.org/viewcvs.cgi/forrest/
