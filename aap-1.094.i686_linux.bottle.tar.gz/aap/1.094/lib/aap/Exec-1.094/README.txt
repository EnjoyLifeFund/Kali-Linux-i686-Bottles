This is the README.txt file for Aap, the recipe executive of the A-A-P project.

Aap executes recipes.  See the documentation in the "doc" directory.  Also see
http://www.a-a-p.org.  If you are still missing the explanation you need, you
can look at the Python source to find out how it really works...


WARNING: Not everything has been tested in every possible situation.
         USE WITH CARE!  There is no guarantee Aap will work as expected.


For downloading, installing and updating, see:
	http://www.a-a-p.org/download.html

To run Aap you need to have Python version 1.5 or later installed.


INSTALL

Installing isn't required, you can run "./aap" directly.

To make Aap available to others using the same system and to avoid having to
type the path to "aap" you can do this:

	./aap install


RUN

Read the tutorial to see plenty of examples.  A quick overview of the command
line options is obtained with:

	./aap --help


USING A PROXY

If you are behind a firewall that uses a proxy server, you must tell Python
where that server is. This is done by setting an environment variable. Here
are a few examples:

   sh-like shell:   export http_proxy="http://www.someproxy.com:3128"
   Csh-like shell:  setenv http_proxy "http://www.someproxy.com:3128"

Put one of these lines in your ~/.cshrc, ~/.profile or ~/.shinit.

This is a common method, you might already have this setup for other
applications.


KNOWN PROBLEMS

Aap works properly on Unix.  This is tested regularly.
Aap mostly works on MS-Windows NT, 2000 and XP.  On MS-Windows 95 and 98 the
failure of an external command is not detected (this is a problem with the
Python os.system() function).  MS-Windows it not tested often.
Aap mostly works on Mac OS X (it's very close to Unix).
Aap has not been tested on other systems yet.

Cached remote files are never outdated, you need to delete them manually.

Python 2.2.1 has a bug in pre.py (version 2.2.2 is OK).  Either upgrade to a
newer version of Python or apply this patch.  You can either apply the patch
where your python libraries are located, or make a copy of pre.py to the Aap
directory and patch it there.

Example:

	cd /usr/local/lib/python2.2
	patch < ~/thepatchfile

-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
*** /usr/local/lib/python2.2/pre.py~	Sat May 18 17:38:28 2002
--- /usr/local/lib/python2.2/pre.py	Mon Sep  2 18:36:37 2002
***************
*** 364,370 ****
              # See if repl contains group references
              try:
                  repl = pcre_expand(_Dummy, repl)
!             except error:
                  m = MatchObject(self, source, 0, end, [])
                  repl = lambda m, repl=repl, expand=pcre_expand: expand(m, repl)
              else:
--- 364,372 ----
              # See if repl contains group references
              try:
                  repl = pcre_expand(_Dummy, repl)
! 	    # Was: except error:
! 	    # Fixed according to 2.2.2 version of the library.
!             except (error, TypeError):
                  m = MatchObject(self, source, 0, end, [])
                  repl = lambda m, repl=repl, expand=pcre_expand: expand(m, repl)
              else:
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

After applying this patch run python twice to generate the pre.pyc and pre.pyo
files.  You need to do this with "root" permissions:
	python -c "import pre"
	python -O -c "import pre"
