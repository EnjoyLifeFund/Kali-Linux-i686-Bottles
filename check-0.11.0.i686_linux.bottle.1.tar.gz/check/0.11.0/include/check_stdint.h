#ifndef _CHECK_CHECK_STDINT_H
#define _CHECK_CHECK_STDINT_H 1
#ifndef _GENERATED_STDINT_H
#define _GENERATED_STDINT_H "check 0.11.0"
/* generated using gnu compiler gcc-7 (Debian 7.2.0-4) 7.2.0 */
#define _STDINT_HAVE_STDINT_H 1
#include <stdint.h>
#endif
#endif
